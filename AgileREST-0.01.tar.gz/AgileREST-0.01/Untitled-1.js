{
    "grid_name": "",
    "table_name": "",
    "agile_rest_table_id": "",
    "columns": [],
    "grid": {
        "head": [],
        "data": [],
        "rows": [],
        "headers": [],
        "ids": [],
        "widths": [],
        "colaligns": [],
        "coltypes": [],
        "colsorting": []
    }
}