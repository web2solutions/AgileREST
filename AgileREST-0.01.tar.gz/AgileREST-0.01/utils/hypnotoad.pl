use Mojo::Server::Hypnotoad;

my $hypnotoad = Mojo::Server::Hypnotoad->new;
$hypnotoad->run('/Users/eduardoalmeida/apps/AgileREST/script/agile_rest');
