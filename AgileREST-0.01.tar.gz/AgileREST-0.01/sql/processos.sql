﻿-- Table: processos

-- DROP TABLE processos;

CREATE TABLE processos
(
  processo_id serial NOT NULL,
  "processo" character varying(255) NOT NULL,
  CONSTRAINT processos_pkey PRIMARY KEY (processo_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE processos
  OWNER TO eduardoalmeida;