﻿-- Table: agile_rest_table

-- DROP TABLE agile_rest_table;

CREATE TABLE agile_rest_table
(
  agile_rest_table_id serial NOT NULL,
  table_name character varying(400) NOT NULL,
  grid_name character varying(400) NOT NULL,
  grid_date_format character varying(100) DEFAULT '%m-%d-%Y'::character varying,
  settings jsonb,
  CONSTRAINT agile_rest_table_pkey PRIMARY KEY (agile_rest_table_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE agile_rest_table
  OWNER TO eduardoalmeida;


-- Table: agile_rest_column

-- DROP TABLE agile_rest_column;

CREATE TABLE agile_rest_column
(
  agile_rest_column_id serial NOT NULL,
  agile_rest_table_id integer NOT NULL,
  column_name character varying(400) NOT NULL,
  column_type character varying(100) DEFAULT 'varchar(300)'::character varying,
  dhtmlx_grid_header character varying(400) NOT NULL,
  dhtmlx_grid_type character varying(20) DEFAULT 'txttxt'::character varying,
  dhtmlx_grid_sorting character varying(10) DEFAULT 'str'::character varying,
  dhtmlx_grid_width character varying(10) DEFAULT '*'::character varying,
  dhtmlx_grid_align character varying(10) DEFAULT 'left'::character varying,
  dhtmlx_grid_footer character varying(400) DEFAULT ''::character varying,
  dhtmlx_form_length character varying,
  dhtmlx_form_type character varying NOT NULL DEFAULT 'input'::character varying,
  dhtmlx_form_mask character varying(255) DEFAULT ''::character varying,
  has_fk integer NOT NULL DEFAULT 0,
  foreign_table_name character varying(300) DEFAULT ''::character varying,
  foreign_column_name character varying(300) DEFAULT ''::character varying,
  CONSTRAINT agile_rest_column_pkey PRIMARY KEY (agile_rest_column_id),
  CONSTRAINT agile_rest_table_id_fkey FOREIGN KEY (agile_rest_table_id)
      REFERENCES agile_rest_table (agile_rest_table_id) MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE RESTRICT
)
WITH (
  OIDS=FALSE
);
ALTER TABLE agile_rest_column
  OWNER TO eduardoalmeida;


-- Table: api_access_token

-- DROP TABLE api_access_token;

CREATE TABLE api_access_token
(
  api_access_token_id serial NOT NULL,
  person_id integer NOT NULL,
  token text,
  date_creation bigint,
  date_expiration bigint,
  active_status integer NOT NULL DEFAULT 0,
  CONSTRAINT api_access_token_pkey PRIMARY KEY (api_access_token_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE api_access_token
  OWNER TO eduardoalmeida;


-- Table: api_allowed_origin

-- DROP TABLE api_allowed_origin;

CREATE TABLE api_allowed_origin
(
  api_allowed_origin_id serial NOT NULL,
  user_id integer NOT NULL,
  origin text,
  CONSTRAINT api_allowed_origin_pkey PRIMARY KEY (api_allowed_origin_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE api_allowed_origin
  OWNER TO eduardoalmeida;



-- Table: groups

-- DROP TABLE groups;

CREATE TABLE groups
(
  group_id serial NOT NULL,
  "group" character varying(255) NOT NULL,
  CONSTRAINT groups_pkey PRIMARY KEY (group_id),
  CONSTRAINT group_ukey UNIQUE ("group")
)
WITH (
  OIDS=FALSE
);
ALTER TABLE groups
  OWNER TO eduardoalmeida;



-- Table: persons

-- DROP TABLE persons;

CREATE TABLE persons
(
  person_id serial NOT NULL,
  company_id integer NOT NULL,
  company_branch_id integer NOT NULL,
  group_id integer NOT NULL,
  first_name character varying(255) NOT NULL,
  last_name character varying(255) NOT NULL,
  email character varying(255) DEFAULT ''::character varying,
  username character varying(300),
  password character varying(300),
  title character varying(255),
  status character varying(255) DEFAULT 'Active'::character varying,
  "group" character varying(255) NOT NULL DEFAULT 'usuario'::character varying,
  birth date,
  CONSTRAINT persons_pkey PRIMARY KEY (person_id),
  CONSTRAINT group_fkey FOREIGN KEY ("group")
      REFERENCES groups ("group") MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT group_id_fkey FOREIGN KEY (group_id)
      REFERENCES groups (group_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);
ALTER TABLE persons
  OWNER TO eduardoalmeida;


 -- hosts allowed to fecth content from API
insert into api_allowed_origin(origin) values('http://mac.web2.eti.br');
insert into api_allowed_origin(origin) values('http://mac.web2.eti.br:3000');
insert into api_allowed_origin(origin) values('http://www.dhtmlx.com.br:3000');
insert into api_allowed_origin(origin) values('http://dhtmlx.com.br:3000');
insert into api_allowed_origin(origin) values('http://www.dhtmlx.com.br');
insert into api_allowed_origin(origin) values('http://dhtmlx.com.br');
insert into api_allowed_origin(origin) values('http://web2solutions.com.br');
insert into api_allowed_origin(origin) values('http://www.web2solutions.com.br');


----- END






-- Persons' triggers

CREATE OR REPLACE FUNCTION person_update_password() RETURNS trigger AS $$
BEGIN
    IF tg_op = 'INSERT' OR tg_op = 'UPDATE' THEN
	IF NEW.password <> OLD.password THEN
		NEW.password = encode( digest(NEW.password, 'sha256') , 'hex');
	END IF;
	RETURN NEW;
    END IF;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_person_update_password
BEFORE INSERT OR UPDATE ON persons
FOR EACH ROW EXECUTE PROCEDURE person_update_password();

--

CREATE OR REPLACE FUNCTION person_update_username() RETURNS trigger AS $$
BEGIN
    IF tg_op = 'INSERT' OR tg_op = 'UPDATE' THEN
	IF NEW.email <> OLD.email THEN
		NEW.username = NEW.email;
	END IF;
	RETURN NEW;
    END IF;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_person_update_username
BEFORE INSERT OR UPDATE ON persons
FOR EACH ROW EXECUTE PROCEDURE person_update_username();

---------------------------- Persons
