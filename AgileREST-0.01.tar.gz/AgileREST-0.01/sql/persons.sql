﻿--DROP TABLE persons;

CREATE TABLE persons
(
  person_id serial NOT NULL,
  company_id integer NOT NULL,
  company_branch_id integer NOT NULL,
  
  "group" character varying(255) NOT NULL DEFAULT 'usuario',
  
  "is_client_group"	integer NOT NULL DEFAULT 0,
  
  "client_group_id"	integer NOT NULL DEFAULT 0,
  
  name character varying(255) NOT NULL,
  email character varying(255) NOT NULL DEFAULT ''::character varying,
  username character varying(300),
  password character varying(300),
  title character varying(255),
  birth_date date,
  gender character varying(30),
  marital_status character varying(100),
  occupation character varying(100),
  nationality character varying(100),

  
  brazilian_rg character varying(40),
  brazilian_cpf character varying(40),
  brazilian_ctps character varying(40),
  brazilian_ctps_serie character varying(40),
  brazilian_titulo_eleitor character varying(40),
  brazilian_oab character varying(50),
  brazilian_cnpj character varying(50),
  brazilian_inscricao_estadual character varying(50),
  brazilian_inscricao_municipal character varying(50),

  
  trading_name character varying(255),
  company_name character varying(255),
  is_offshore integer NOT NULL DEFAULT 0,

  --Escritorio

  notes text,

  date_created timestamp,

  --IsAbleToPubPasta --LoginSiteAdv --SenhaSiteAdv --HasPublished --IdClienteSiteAdv 
  --idIntegrante --legal_fee_id --Matricula --AI --IsAllowNC
  --RegimeApuracaoImpostos --EnquadramentoTributario

  -- resources and access
  web_site_access  integer NOT NULL DEFAULT 0,
  web_site_last_login  timestamp,
  rest_api_access  integer NOT NULL DEFAULT 0,
  rest_api_alowed_requests_per_day  integer NOT NULL DEFAULT 0,
  rest_api_last_login  timestamp,
  storage_quota  integer NOT NULL DEFAULT 200, -- in MB
  time_zone character varying(255) NOT NULL DEFAULT 'America/Sao_Paulo',
  
  status INTEGER NOT NULL DEFAULT 0,
  
  
  CONSTRAINT persons_pkey PRIMARY KEY (person_id),
  CONSTRAINT group_fkey FOREIGN KEY ("group")
      REFERENCES groups ("group") MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE RESTRICT
)
WITH (
  OIDS=FALSE
);
ALTER TABLE persons
  OWNER TO eduardoalmeida;
